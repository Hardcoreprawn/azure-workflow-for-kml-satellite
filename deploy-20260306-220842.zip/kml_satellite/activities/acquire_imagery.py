"""Acquire imagery activity — search, select, and order satellite imagery.

This activity takes a processed AOI, queries the configured imagery
provider's catalogue, selects the best matching scene, and submits an
order.  It does **not** poll or download — those are handled by the
orchestrator's timer-based polling loop and the ``download_imagery``
activity (M-2.4).

The function returns enough information for the orchestrator to drive
the poll/download cycle: ``order_id``, ``scene_id``, and ``provider``.

Engineering standards:
    PID 7.4.1  Zero-Assumption Input Handling — validate AOI and filters.
    PID 7.4.2  Fail Loudly — ``ProviderSearchError`` / ``ProviderOrderError``
               propagate to the orchestrator for retry / dead-letter.
    PID 7.4.4  Idempotent — same AOI + filters → same best scene selection
               (deterministic sort by cloud cover ascending).
    PID 7.4.5  Explicit — typed models, named constants, no magic strings.
    PID 7.4.6  Observability — structured logging at activity boundaries.

References:
    PID FR-3.8  (submit search queries to provider API)
    PID FR-3.9  (poll asynchronous job status)
    PID FR-5.3  (Durable Functions for imagery acquisition)
    PID Section 7.2  (Orchestration Pattern — Fan-Out per Polygon)
"""

from __future__ import annotations

import logging
from typing import Any

from kml_satellite.core.constants import (
    DEFAULT_IMAGERY_MAX_CLOUD_COVER_PCT,
    DEFAULT_MAX_OFF_NADIR_DEG,
    DEFAULT_MAX_RESOLUTION_M,
    MIN_RESOLUTION_M,
)
from kml_satellite.core.exceptions import PipelineError
from kml_satellite.models.aoi import AOI
from kml_satellite.models.imagery import ImageryFilters
from kml_satellite.providers.base import ProviderError
from kml_satellite.providers.factory import get_provider
from kml_satellite.utils.helpers import build_provider_config

logger = logging.getLogger("kml_satellite.activities.acquire_imagery")


class ImageryAcquisitionError(PipelineError):
    """Raised when imagery acquisition fails.

    Attributes:
        message: Human-readable error description.
        retryable: Whether the orchestrator should retry the operation.
    """

    default_stage = "acquire_imagery"
    default_code = "IMAGERY_ACQUISITION_FAILED"

    def __init__(self, message: str, *, retryable: bool = False) -> None:
        super().__init__(message, retryable=retryable)


def acquire_imagery(
    aoi_dict: dict[str, Any],
    *,
    provider_name: str = "planetary_computer",
    provider_config: dict[str, Any] | None = None,
    filters_dict: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Search for imagery, select the best scene, and submit an order.

    Args:
        aoi_dict: Serialised AOI dict from the ``prepare_aoi`` activity.
        provider_name: Name of the imagery provider to use.
        provider_config: Optional provider configuration overrides.
        filters_dict: Optional imagery filter overrides.

    Returns:
        A dict containing:
        - ``order_id``: Provider-specific order identifier.
        - ``scene_id``: The selected scene identifier.
        - ``provider``: Provider name.
        - ``cloud_cover_pct``: Cloud cover of the selected scene.
        - ``acquisition_date``: ISO 8601 acquisition date string.
        - ``spatial_resolution_m``: Ground sample distance in metres.
        - ``asset_url``: Direct asset URL (if available).
        - ``aoi_feature_name``: Name of the AOI being processed.

    Raises:
        ImageryAcquisitionError: If no imagery is found or ordering fails.
    """
    # Deserialise AOI (PID 7.4.1 — validate input)
    try:
        aoi = AOI.from_dict(aoi_dict)
    except (TypeError, KeyError, ValueError) as exc:
        msg = f"Invalid AOI payload: {exc}"
        raise ImageryAcquisitionError(msg, retryable=False) from exc

    logger.info(
        "acquire_imagery started | feature=%s | provider=%s",
        aoi.feature_name,
        provider_name,
    )

    # Build provider config
    config = build_provider_config(provider_name, provider_config)

    # Build imagery filters.
    try:
        filters = _build_filters(filters_dict)
    except (TypeError, ValueError) as exc:
        msg = f"Invalid imagery filters payload: {exc}"
        raise ImageryAcquisitionError(msg, retryable=False) from exc

    # Get provider adapter
    try:
        provider = get_provider(provider_name, config)
    except ProviderError as exc:
        msg = f"Failed to create provider {provider_name!r}: {exc}"
        raise ImageryAcquisitionError(msg, retryable=False) from exc

    # Search
    try:
        results = provider.search(aoi, filters)
    except ProviderError as exc:
        msg = f"Imagery search failed for {aoi.feature_name!r}: {exc}"
        raise ImageryAcquisitionError(msg, retryable=exc.retryable) from exc

    if not results:
        msg = f"No imagery found for {aoi.feature_name!r} with provider {provider_name!r}"
        logger.warning(msg)
        raise ImageryAcquisitionError(msg, retryable=False)

    # Select best scene (first result — already sorted by cloud cover ascending)
    best = results[0]

    logger.info(
        "Best scene selected | feature=%s | scene=%s | cloud=%.1f%% | resolution=%.1fm",
        aoi.feature_name,
        best.scene_id,
        best.cloud_cover_pct,
        best.spatial_resolution_m,
    )

    # Order
    try:
        order = provider.order(best.scene_id)
    except ProviderError as exc:
        msg = f"Order failed for scene {best.scene_id!r}: {exc}"
        raise ImageryAcquisitionError(msg, retryable=exc.retryable) from exc

    logger.info(
        "Order submitted | feature=%s | order_id=%s | scene=%s | provider=%s",
        aoi.feature_name,
        order.order_id,
        order.scene_id,
        order.provider,
    )

    return {
        "order_id": order.order_id,
        "scene_id": order.scene_id,
        "provider": order.provider,
        "cloud_cover_pct": best.cloud_cover_pct,
        "acquisition_date": best.acquisition_date.isoformat(),
        "spatial_resolution_m": best.spatial_resolution_m,
        "asset_url": best.asset_url,
        "aoi_feature_name": aoi.feature_name,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_filters(
    overrides: dict[str, Any] | None,
) -> ImageryFilters:
    """Build ``ImageryFilters`` from an optional overrides dict.

    Returns default filters if *overrides* is ``None``.
    """
    if overrides is None:
        return ImageryFilters()

    from datetime import datetime

    date_start = overrides.get("date_start")
    date_end = overrides.get("date_end")

    if isinstance(date_start, str):
        try:
            date_start = datetime.fromisoformat(date_start)
        except ValueError as exc:
            msg = "filters.date_start must be ISO 8601"
            raise ValueError(msg) from exc
    if isinstance(date_end, str):
        try:
            date_end = datetime.fromisoformat(date_end)
        except ValueError as exc:
            msg = "filters.date_end must be ISO 8601"
            raise ValueError(msg) from exc

    raw_collections = overrides.get("collections", [])
    if raw_collections is None:
        collections: list[str] = []
    else:
        if not isinstance(raw_collections, list):
            msg = "filters.collections must be a list of strings"
            raise ValueError(msg)
        if not all(isinstance(c, str) and c.strip() for c in raw_collections):
            msg = "filters.collections must contain non-empty strings"
            raise ValueError(msg)
        collections = list(raw_collections)

    return ImageryFilters(
        max_cloud_cover_pct=float(
            overrides.get("max_cloud_cover_pct", DEFAULT_IMAGERY_MAX_CLOUD_COVER_PCT)
        ),
        max_off_nadir_deg=float(overrides.get("max_off_nadir_deg", DEFAULT_MAX_OFF_NADIR_DEG)),
        min_resolution_m=float(overrides.get("min_resolution_m", MIN_RESOLUTION_M)),
        max_resolution_m=float(overrides.get("max_resolution_m", DEFAULT_MAX_RESOLUTION_M)),
        date_start=date_start,
        date_end=date_end,
        collections=collections,
    )
