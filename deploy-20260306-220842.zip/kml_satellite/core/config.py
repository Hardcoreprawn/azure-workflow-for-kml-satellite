"""Pipeline configuration loaded from environment variables.

All configuration values have sensible defaults aligned with the PID.
Azure Functions app settings (or ``local.settings.json`` for local dev)
are the source of truth.

Fail-fast validation (Issue #48):
    ``from_env()`` raises ``ConfigValidationError`` if any numeric
    value is out of its valid range.  This prevents latent runtime
    errors by catching bad configuration at startup.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

from kml_satellite.core.constants import (
    DEFAULT_AOI_BUFFER_M,
    DEFAULT_AOI_MAX_AREA_HA,
    DEFAULT_IMAGERY_MAX_CLOUD_COVER_PCT,
    DEFAULT_IMAGERY_RESOLUTION_TARGET_M,
    DEFAULT_INPUT_CONTAINER,
    DEFAULT_OUTPUT_CONTAINER,
    MAX_PERCENTAGE,
    MIN_PERCENTAGE,
)
from kml_satellite.core.exceptions import PipelineError


class ConfigValidationError(PipelineError):
    """Raised when configuration values are out of valid range.

    Attributes:
        key: The configuration key that failed validation.
        value: The invalid value.
        message: Human-readable description of the valid range.
    """

    default_stage = "config"
    default_code = "CONFIG_VALIDATION_FAILED"

    def __init__(self, key: str, value: object, message: str) -> None:
        self.key = key
        self.value = value
        super().__init__(message)

    def __str__(self) -> str:
        return f"Invalid configuration {self.key}={self.value!r}: {self.message}"


@dataclass(frozen=True, slots=True)
class PipelineConfig:
    """Immutable pipeline configuration.

    Loaded once at function startup and threaded through the orchestrator.

    Attributes:
        kml_input_container: Blob container for incoming KML files.
        kml_output_container: Blob container for processed outputs.
        imagery_provider: Active imagery provider (``planetary_computer`` or ``skywatch``).
        imagery_resolution_target_m: Target spatial resolution in metres.
        imagery_max_cloud_cover_pct: Maximum acceptable cloud cover percentage.
        aoi_buffer_m: Buffer distance in metres applied to each polygon's bounding box.
        aoi_max_area_ha: Area threshold (ha) above which a warning is logged.
        keyvault_url: Azure Key Vault URI (empty when running locally).
    """

    kml_input_container: str = DEFAULT_INPUT_CONTAINER
    kml_output_container: str = DEFAULT_OUTPUT_CONTAINER
    imagery_provider: str = "planetary_computer"
    imagery_resolution_target_m: float = DEFAULT_IMAGERY_RESOLUTION_TARGET_M
    imagery_max_cloud_cover_pct: float = DEFAULT_IMAGERY_MAX_CLOUD_COVER_PCT
    aoi_buffer_m: float = DEFAULT_AOI_BUFFER_M
    aoi_max_area_ha: float = DEFAULT_AOI_MAX_AREA_HA
    keyvault_url: str = ""

    @classmethod
    def from_env(cls) -> PipelineConfig:
        """Load and validate configuration from environment variables.

        Environment variable names match the keys in
        ``local.settings.json.template``.

        Raises:
            ConfigValidationError: If a numeric value is out of range
                or a required string value is empty.
            ValueError: If a numeric environment variable cannot be
                parsed (e.g. ``AOI_BUFFER_M=abc``).
        """
        config = cls(
            kml_input_container=os.getenv(
                "DEFAULT_INPUT_CONTAINER",
                os.getenv("KML_INPUT_CONTAINER", DEFAULT_INPUT_CONTAINER),
            ),
            kml_output_container=os.getenv(
                "DEFAULT_OUTPUT_CONTAINER",
                os.getenv("KML_OUTPUT_CONTAINER", DEFAULT_OUTPUT_CONTAINER),
            ),
            imagery_provider=os.getenv("IMAGERY_PROVIDER", "planetary_computer"),
            imagery_resolution_target_m=float(
                os.getenv(
                    "IMAGERY_RESOLUTION_TARGET_M",
                    str(DEFAULT_IMAGERY_RESOLUTION_TARGET_M),
                )
            ),
            imagery_max_cloud_cover_pct=float(
                os.getenv(
                    "IMAGERY_MAX_CLOUD_COVER_PCT",
                    str(DEFAULT_IMAGERY_MAX_CLOUD_COVER_PCT),
                )
            ),
            aoi_buffer_m=float(os.getenv("AOI_BUFFER_M", str(DEFAULT_AOI_BUFFER_M))),
            aoi_max_area_ha=float(os.getenv("AOI_MAX_AREA_HA", str(DEFAULT_AOI_MAX_AREA_HA))),
            keyvault_url=os.getenv("KEYVAULT_URL", ""),
        )
        _validate(config)
        return config


def _validate(config: PipelineConfig) -> None:
    """Validate configuration ranges.  Raises ``ConfigValidationError``."""
    if config.imagery_resolution_target_m <= 0:
        raise ConfigValidationError(
            "IMAGERY_RESOLUTION_TARGET_M",
            config.imagery_resolution_target_m,
            "must be > 0 (metres)",
        )

    if not MIN_PERCENTAGE <= config.imagery_max_cloud_cover_pct <= MAX_PERCENTAGE:
        raise ConfigValidationError(
            "IMAGERY_MAX_CLOUD_COVER_PCT",
            config.imagery_max_cloud_cover_pct,
            f"must be between {MIN_PERCENTAGE:g} and {MAX_PERCENTAGE:g} (percentage)",
        )

    if config.aoi_buffer_m < 0:
        raise ConfigValidationError(
            "AOI_BUFFER_M",
            config.aoi_buffer_m,
            "must be >= 0 (metres)",
        )

    if config.aoi_max_area_ha <= 0:
        raise ConfigValidationError(
            "AOI_MAX_AREA_HA",
            config.aoi_max_area_ha,
            "must be > 0 (hectares)",
        )

    if not config.kml_input_container:
        raise ConfigValidationError(
            "DEFAULT_INPUT_CONTAINER",
            config.kml_input_container,
            "must not be empty",
        )

    if not config.kml_output_container:
        raise ConfigValidationError(
            "DEFAULT_OUTPUT_CONTAINER",
            config.kml_output_container,
            "must not be empty",
        )


def config_get_int(data: dict[str, object], key: str, default: int) -> int:
    """Extract an integer from a dict with defensive type coercion (Issue #102).

    Consolidates the previously duplicated ``_int_cfg`` and ``_int_val`` helpers
    used in multiple orchestrator locations. Handles graceful fallback for:
    - Missing keys
    - Non-numeric types
    - Parsing errors (non-numeric strings, overflow)

    Args:
        data: Source dictionary (activity input, event dict, etc.).
        key: Configuration key to extract.
        default: Value to return if key is missing, type unsupported, or parsing fails.

    Returns:
        Extracted integer, or default if extraction fails.

    Examples:
        >>> config_get_int({"batch_size": "10"}, "batch_size", 1)
        10
        >>> config_get_int({"timeout": 30.5}, "timeout", 1)
        30
        >>> config_get_int({}, "missing_key", 42)
        42
        >>> config_get_int({"value": "not_numeric"}, "value", 42)
        42
    """
    raw = data.get(key, default)

    if not isinstance(raw, int | float | str):
        # Unsupported type: bool, list, dict, etc. → return default
        return default

    if isinstance(raw, int):
        # Already an integer
        return raw

    if isinstance(raw, float):
        # Coerce float to int (truncation)
        return int(raw)

    # raw is str: attempt to parse (handles both "10" and "15.5")
    try:
        # First try to parse as int directly
        return int(raw)
    except ValueError:
        # If that fails, try parsing as float first, then convert to int
        try:
            return int(float(raw))
        except (ValueError, OverflowError):
            # Non-numeric string or overflow → return default
            return default
